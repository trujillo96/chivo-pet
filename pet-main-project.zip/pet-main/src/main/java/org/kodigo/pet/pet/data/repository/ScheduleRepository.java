package org.kodigo.pet.pet.data.repository;

import org.kodigo.pet.pet.data.models.Pet;
import org.kodigo.pet.pet.data.models.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface ScheduleRepository extends JpaRepository<Schedule, Integer> {
    @Query("FROM Schedule WHERE schedule_id=?1")
    List<Schedule> findByVeterinaryId(int veterinary_id);
}
