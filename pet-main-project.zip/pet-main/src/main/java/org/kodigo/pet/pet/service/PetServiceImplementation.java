package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Pet;
import org.kodigo.pet.pet.data.payloads.request.PetRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.data.repository.PetRepository;
import org.kodigo.pet.pet.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PetServiceImplementation implements PetService {
    @Autowired
    PetRepository petRepository;

    @Override
    public MessageResponse createPet(PetRequest petRequest) {
        Pet newPet = new Pet();
        newPet.setName(petRequest.getName());
        newPet.setBreed(petRequest.getBreed());
        newPet.setBirth(petRequest.getBirth());
        newPet.setDeleted(petRequest.getDeleted());
        newPet.setClient_id(petRequest.getClient_id());

        petRepository.save(newPet);

        return new MessageResponse("New Pet created successfully");
    }

    @Override
    public Optional<Pet> updatePet(Integer pet_id, PetRequest petRequest) throws ResourceNotFoundException {
        Optional<Pet> pet = petRepository.findById(pet_id);

        if(pet.isEmpty())
        {
            throw new ResourceNotFoundException("Pet", "id", pet_id);
        }
        else
        pet.get().setName(petRequest.getName());
        pet.get().setBreed(petRequest.getBreed());
        pet.get().setBirth(petRequest.getBirth());
        pet.get().setDeleted(petRequest.getDeleted());

        petRepository.save(pet.get());

        return pet;

    }

    @Override
    public void deletePet(Integer pet_id) throws ResourceNotFoundException {
        if(petRepository.getById(pet_id).getPet_id().equals(pet_id))
        {
            petRepository.deleteById(pet_id);
        }
        else throw new ResourceNotFoundException("Pet", "id", pet_id);
    }

    @Override
    public Pet getASinglePet(Integer pet_id) throws ResourceNotFoundException {
        return petRepository.findById(pet_id).orElseThrow(() -> new ResourceNotFoundException("Pet", "id", pet_id));
    }

    @Override
    public List<Pet> getAClientPet(Integer client_id) throws ResourceNotFoundException {
        return petRepository.findByClientId(client_id);
    }

    @Override
    public List<Pet> getAllPets() {
        return petRepository.findAll();
    }
}
