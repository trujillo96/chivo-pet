package org.kodigo.pet.pet.data.payloads.request;

import lombok.Getter;
import lombok.Setter;
import org.kodigo.pet.pet.data.models.Client;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

public class PetRequest {
    @NotBlank
    @NotNull
    @Getter @Setter
    private String name;
    @NotBlank
    @NotNull
    @Getter @Setter
    private String breed;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Date birth;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Integer deleted;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Integer client_id;
}
