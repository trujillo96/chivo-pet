package org.kodigo.pet.pet.data.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name="veterinary")
public class Veterinary {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter
    @Setter
    @Column(name = "veterinary_id")
    private Integer veterinary_id;
    @Getter
    @Setter
    private String veterinary_name;
    @Getter
    @Setter
    private Integer city_id;
    @Getter
    @Setter
    private String street;
    @Getter
    @Setter
    private Integer phone;


    public Veterinary() {
    }

    public Veterinary(Integer veterinary_id, String veterinary_name, Integer city_id, String street, Integer phone) {
        this.veterinary_id = veterinary_id;
        this.veterinary_name = veterinary_name;
        this.city_id = city_id;
        this.street = street;
        this.phone = phone;

    }

    @Override
    public String toString() {
        return "Veterinary{" +
                "veterinary_id=" + veterinary_id +
                ", veterinary_name='" + veterinary_name + '\'' +
                ", city_id=" + city_id +
                ", street='" + street + '\'' +
                ", phone=" + phone +

                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Veterinary that = (Veterinary) o;
        return Objects.equals(veterinary_id, that.veterinary_id) && Objects.equals(veterinary_name, that.veterinary_name) && Objects.equals(city_id, that.city_id) && Objects.equals(street, that.street) && Objects.equals(phone, that.phone) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(veterinary_id, veterinary_name, city_id, street, phone);
    }
}
