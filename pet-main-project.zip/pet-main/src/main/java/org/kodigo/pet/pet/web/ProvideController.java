package org.kodigo.pet.pet.web;

import org.kodigo.pet.pet.data.models.Provide;
import org.kodigo.pet.pet.data.models.Services;
import org.kodigo.pet.pet.service.ProvideService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("/provide")
@RestController
public class ProvideController {
    @Autowired
    ProvideService provideService;

    @GetMapping("/all")
    public ResponseEntity<List<Provide>> getAllProvide(){
        List<Provide> provide = provideService.getAllProvide();
        return new ResponseEntity<>(provide, HttpStatus.OK);
    }
}
