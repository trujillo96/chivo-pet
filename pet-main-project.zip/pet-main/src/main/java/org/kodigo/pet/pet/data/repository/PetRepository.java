package org.kodigo.pet.pet.data.repository;

import org.kodigo.pet.pet.data.models.Client;
import org.kodigo.pet.pet.data.models.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PetRepository extends JpaRepository<Pet, Integer> {
    @Query("FROM Pet WHERE client_id=?1")
    List<Pet> findByClientId(int clientId);
}
