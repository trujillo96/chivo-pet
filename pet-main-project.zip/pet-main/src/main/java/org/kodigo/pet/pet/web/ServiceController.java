package org.kodigo.pet.pet.web;

import org.kodigo.pet.pet.data.models.Services;
import org.kodigo.pet.pet.data.payloads.request.ServiceRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.service.ServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/service")
@RestController
public class ServiceController {

    @Autowired
    ServiceService serviceService;

    @GetMapping("/all")
    public ResponseEntity<List<Services>> getAllService(){
        List<Services> services = serviceService.getAllService();
        return new ResponseEntity<>(services, HttpStatus.OK);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<Services> getServiceById(@PathVariable("id") Integer id){
        Services service = serviceService.getASingleService(id);
        return new ResponseEntity<>(service, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<MessageResponse> addService(@RequestBody ServiceRequest service){
        MessageResponse newService = serviceService.createService(service);
        return new ResponseEntity<>(newService, HttpStatus.CREATED);
    }

    @PutMapping("/update/{id}")
    public Optional<Services> updateService(@PathVariable Integer id, @RequestBody ServiceRequest service){
        return serviceService.updateService(id, service);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteService(@PathVariable("id") Integer id){
        serviceService.deleteService(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
