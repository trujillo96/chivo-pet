package org.kodigo.pet.pet.data.models;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name="user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter @Setter
    @Column(name = "user_id")
    private Integer userId;
    @Getter @Setter
    private String email;
    @Getter @Setter
    private String password;
    @Getter @Setter
    private Integer roleId;



    public User() {
    }

    public User(Integer userId, String email, String password, Integer roleId) {
        this.userId = userId;
        this.email = email;
        this.password = password;
        this.roleId = roleId;
    }

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", email'" + email + '\'' +
                ", password='" + password + '\'' +
                ", roleId='" + roleId + '\'' +


                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(userId, user.userId) && Objects.equals(email, user.email) && Objects.equals(password, user.password) && Objects.equals(roleId, user.roleId);
    }
    @Override
    public int hashCode() {
        return Objects.hash(userId,email,password,roleId);
    }
}
