package org.kodigo.pet.pet.data.payloads.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class VeterinaryRequest {
    @NotBlank
    @NotNull
    @Getter
    @Setter
    private String veterinaryName;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Integer cityId;
    @NotBlank
    @NotNull
    @Getter @Setter
    private String street;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Integer phone;

}
