package org.kodigo.pet.pet.data.repository;

import org.kodigo.pet.pet.data.models.Provide;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProvideRepository extends JpaRepository<Provide, Integer> {
    @Query("FROM Provide WHERE pet_id=?1")
    List<Provide> findByPetId(int pet_id);

}
