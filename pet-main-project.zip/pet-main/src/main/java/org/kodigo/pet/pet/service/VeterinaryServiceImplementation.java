package org.kodigo.pet.pet.service;


import org.kodigo.pet.pet.data.models.Veterinary;
import org.kodigo.pet.pet.data.payloads.request.VeterinaryRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.data.repository.VeterinaryRepository;
import org.kodigo.pet.pet.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VeterinaryServiceImplementation implements VeterinaryService{
    @Autowired
    VeterinaryRepository veterinaryRepository;

    public VeterinaryServiceImplementation(VeterinaryRepository veterinaryRepository) {
        this.veterinaryRepository = veterinaryRepository;
    }

    @Override
    public MessageResponse createVeterinary(VeterinaryRequest veterinaryRequest) {
        Veterinary newVeterinary = new Veterinary();
        newVeterinary.setVeterinary_name(veterinaryRequest.getVeterinaryName());
        newVeterinary.setCity_id(veterinaryRequest.getCityId());
        newVeterinary.setStreet(veterinaryRequest.getStreet());
        newVeterinary.setPhone(veterinaryRequest.getPhone());



        veterinaryRepository.save(newVeterinary);


        return new MessageResponse("New Client created successfully" );
    }

    @Override
    public Optional<Veterinary> updateVeterinary(Integer veterinaryId, VeterinaryRequest veterinaryRequest) throws ResourceNotFoundException {
        Optional<Veterinary> veterinary = veterinaryRepository.findById(veterinaryId);
        if(veterinary.isEmpty()){
            throw new ResourceNotFoundException("Veterinary", "id", veterinaryId);
        }else

        veterinary.get().setVeterinary_name(veterinaryRequest.getVeterinaryName());
        veterinary.get().setCity_id(veterinaryRequest.getCityId());
        veterinary.get().setStreet(veterinaryRequest.getStreet());
        veterinary.get().setPhone(veterinaryRequest.getPhone());

        veterinaryRepository.save(veterinary.get());
        return veterinary;


    }

    @Override
    public void deleteVeterinary(Integer veterinaryId) throws ResourceNotFoundException {
        if(veterinaryRepository.getById(veterinaryId).getVeterinary_id().equals(veterinaryId)){
            veterinaryRepository.deleteById(veterinaryId);

        }
        else throw new ResourceNotFoundException("Veterinary", "id", veterinaryId);


    }

    @Override
    public Veterinary getASingleVeterinary(Integer veterinaryId) throws ResourceNotFoundException {
        return veterinaryRepository.findById(veterinaryId)
                .orElseThrow(() -> new ResourceNotFoundException("Veterinary", "veterinay_id", veterinaryId));
    }

    @Override
    public List<Veterinary> getAllVeterinary() {
        return veterinaryRepository.findAll();
    }
}
