package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Pet;
import org.kodigo.pet.pet.data.payloads.request.PetRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public interface PetService {
    MessageResponse createPet(PetRequest petRequest);
    Optional<Pet> updatePet(Integer pet_id, PetRequest petRequest);
    void deletePet(Integer pet_id);
    Pet getASinglePet(Integer pet_id);
    List<Pet> getAClientPet(Integer client_id);
    List<Pet> getAllPets();
}
