package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Client;
import org.kodigo.pet.pet.data.payloads.request.ClientRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.data.repository.ClientRepository;
import org.kodigo.pet.pet.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClientServiceImplementation implements ClientService {
    @Autowired
    ClientRepository clientRepository;

    @Override
    public MessageResponse createClient(ClientRequest clientRequest) {
        Client newClient = new Client();
        newClient.setName(clientRequest.getName());
        newClient.setLastName(clientRequest.getLastName());
        newClient.setPhone(clientRequest.getPhone());
        newClient.setDui(clientRequest.getDui());
        newClient.setUser(clientRequest.getUser());
        newClient.getUser().setRoleId(1);


        clientRepository.save(newClient);



        return new MessageResponse("New Client created successfully" );
    }

    @Override
    public Optional<Client> updateClient(Integer clientId, ClientRequest clientRequest) throws ResourceNotFoundException {
        Optional<Client> client = clientRepository.findById(clientId);
        if (client.isEmpty()) {
            throw new ResourceNotFoundException("Client", "id", clientId);
        } else
            client.get().setName(clientRequest.getName());

        client.get().setDui(clientRequest.getDui());
        client.get().setPhone(clientRequest.getPhone());
        client.get().setLastName(clientRequest.getLastName());
        clientRepository.save(client.get());

        return client;
    }

    @Override
    public void deleteClient(Integer clientId) throws ResourceNotFoundException{
        if(clientRepository.getById(clientId).getClientId().equals(clientId)){
            clientRepository.deleteById(clientId);

        }
        else throw new ResourceNotFoundException("Client", "id", clientId);

    }

    @Override
    public Client getASingleClient(Integer clientId) throws ResourceNotFoundException {
        return clientRepository.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client", "id", clientId));

    }
    @Override
    public Client getClientByUserId(Integer userId) throws ResourceNotFoundException {
        return clientRepository.findByUserId(userId);
    }

    @Override
    public List<Client> getAllClients() {
        return clientRepository.findAll();

    }

}
