package org.kodigo.pet.pet.data.payloads.request;

import lombok.Getter;
import lombok.Setter;
import org.kodigo.pet.pet.data.models.Appointment;
import org.kodigo.pet.pet.data.models.Pet;
import org.kodigo.pet.pet.data.models.Services;
import org.kodigo.pet.pet.data.models.Veterinary;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class ProvideRequest {

    @NotBlank
    @NotNull
    @Getter @Setter
    private Veterinary veterinary;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Pet pet;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Services service;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Appointment appointment;
}
