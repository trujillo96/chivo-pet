package org.kodigo.pet.pet.data.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "service")
public class Services {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter @Setter
    @Column(name = "service_id")
    private Integer service_id;
    @Getter @Setter
    private String service_name;
    @Getter @Setter
    private Integer price;
    @Getter @Setter
    private Integer quantity;

    public Services() {
    }

    public Services(Integer service_id, String service_name, Integer price, Integer quantity) {
        this.service_id = service_id;
        this.service_name = service_name;
        this.price = price;
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "Services{" +
                "service_id=" + service_id +
                ", service_name='" + service_name + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Services services = (Services) o;
        return Objects.equals(service_id, services.service_id) && Objects.equals(service_name, services.service_name) && Objects.equals(price, services.price) && Objects.equals(quantity, services.quantity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(service_id, service_name, price, quantity);
    }
}
