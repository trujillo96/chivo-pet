package org.kodigo.pet.pet.service;


import org.kodigo.pet.pet.data.models.Veterinary;
import org.kodigo.pet.pet.data.payloads.request.VeterinaryRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public interface VeterinaryService {
    MessageResponse createVeterinary(VeterinaryRequest veterinaryRequest);
    Optional<Veterinary> updateVeterinary(Integer veterinaryId, VeterinaryRequest veterinaryRequest);
    void deleteVeterinary(Integer veterinaryId);
    Veterinary getASingleVeterinary(Integer veterinaryId);
    List<Veterinary> getAllVeterinary();
}
