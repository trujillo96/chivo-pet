package org.kodigo.pet.pet.data.payloads.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.sql.Time;
import java.util.Date;
import java.util.TimeZone;
import java.util.Timer;

public class ScheduleRequest {

    @NotBlank
    @NotNull
    @Getter @Setter
    private Date day;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Time start_hour;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Time end_hour;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Integer veterinary_id;
}
