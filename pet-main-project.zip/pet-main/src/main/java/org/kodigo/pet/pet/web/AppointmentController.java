package org.kodigo.pet.pet.web;

import org.kodigo.pet.pet.data.models.Appointment;
import org.kodigo.pet.pet.data.payloads.request.AppointmentRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/appointment")
@RestController
public class AppointmentController {
    @Autowired
    AppointmentService appointmentService;

    @GetMapping("/all")
    public ResponseEntity<List<Appointment>> getAllAppointments(){
        List<Appointment> appointments = appointmentService.getAllAppointments();
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<Appointment> getAppointment(@PathVariable("id") Integer id){
        Appointment appointment = appointmentService.getASingleAppointment(id);
        return new ResponseEntity<>(appointment, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<MessageResponse> addAppointment(@RequestBody AppointmentRequest appointment){
        MessageResponse newAppointment = appointmentService.createAppointment(appointment);
        return new ResponseEntity<>(newAppointment, HttpStatus.CREATED);
    }

    @PutMapping("/update/{id}")
    public Optional<Appointment> updateAppointment(@PathVariable Integer id, @RequestBody AppointmentRequest appointment){
        return appointmentService.updateAppointment(id, appointment);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteAppointment(@PathVariable("id") Integer id){
        appointmentService.deleteAppointment(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }


}
