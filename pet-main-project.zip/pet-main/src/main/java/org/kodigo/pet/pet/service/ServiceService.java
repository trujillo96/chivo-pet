package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Services;
import org.kodigo.pet.pet.data.payloads.request.ServiceRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public interface ServiceService {
    MessageResponse createService(ServiceRequest serviceRequest);
    Optional<Services> updateService(Integer service_id, ServiceRequest serviceRequest);
    void deleteService(Integer service_id);
    Services getASingleService(Integer service_id);
    List<Services> getAllService();
}
