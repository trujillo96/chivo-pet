package org.kodigo.pet.pet.data.payloads.request;


import lombok.Getter;
import lombok.Setter;
import org.kodigo.pet.pet.data.models.User;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class ClientRequest {

    @NotBlank
    @NotNull
    @Getter @Setter
    private String name;
    @NotBlank
    @NotNull
    @Getter @Setter
    private String lastName;
    @NotBlank
    @NotNull
    @Getter @Setter
    private int phone;
    @NotBlank
    @NotNull
    @Getter @Setter
    private String dui;
    @NotBlank
    @NotNull
    @Getter @Setter
    private User user;



}