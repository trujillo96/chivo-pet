package org.kodigo.pet.pet.web;

import org.kodigo.pet.pet.data.models.Pet;
import org.kodigo.pet.pet.data.payloads.request.PetRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/pet")
@RestController
public class PetController {

    @Autowired
    PetService petService;

    @GetMapping("/all")
    public ResponseEntity<List<Pet>> getAllPets(){
        List<Pet> pets = petService.getAllPets();
        return new ResponseEntity<>(pets, HttpStatus.OK);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<Pet> getPetById(@PathVariable("id") Integer id){
        Pet pet = petService.getASinglePet(id);
        return new ResponseEntity<>(pet, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<MessageResponse> addPet(@RequestBody PetRequest pet){
        MessageResponse newPet = petService.createPet(pet);
        return new ResponseEntity<>(newPet, HttpStatus.CREATED);
    }

    @PutMapping("/update/{id}")
    public Optional<Pet> updatePet(@PathVariable Integer id, @RequestBody PetRequest pet){
        return petService.updatePet(id, pet);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deletePet(@PathVariable("id") Integer id){
        petService.deletePet(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
