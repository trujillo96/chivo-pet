package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.User;
import org.kodigo.pet.pet.data.payloads.request.UserRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public interface UserService {
    MessageResponse createUser(UserRequest userRequest);
    Optional<User> updateUser(Integer userId, UserRequest userRequest);
    void deleteUser(Integer userId);
    User getASingleUser(Integer userId);
    User getUserByEmail(String email, String password);
    List<User> getAllUsers();

}
