package org.kodigo.pet.pet.data.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "pet")
public class Pet {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter @Setter
    @Column(name = "pet_id")
    private Integer pet_id;
    @Getter @Setter
    private String name;
    @Getter @Setter
    private String breed;
    @Getter @Setter
    private Date birth;
    @Getter @Setter
    private Integer deleted;
    @Getter @Setter
    private Integer client_id;

    public Pet() {
    }

    public Pet(Integer pet_id, String name, String breed, Date birth, Integer deleted, Integer client_id) {
        this.pet_id = pet_id;
        this.name = name;
        this.breed = breed;
        this.birth = birth;
        this.deleted = deleted;
        this.client_id = client_id;
    }

    @Override
    public String toString() {
        return "Pet{" +
                "pet_id=" + pet_id +
                ", name='" + name + '\'' +
                ", breed='" + breed + '\'' +
                ", birth=" + birth +
                ", deleted=" + deleted +
                ", client_id=" + client_id +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pet pet = (Pet) o;
        return Objects.equals(pet_id, pet.pet_id) && Objects.equals(name, pet.name) && Objects.equals(breed, pet.breed) && Objects.equals(birth, pet.birth) && Objects.equals(deleted, pet.deleted) && Objects.equals(client_id, pet.client_id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pet_id, name, breed, birth, deleted, client_id);
    }
}
