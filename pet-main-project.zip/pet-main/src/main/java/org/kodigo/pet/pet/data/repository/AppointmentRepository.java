package org.kodigo.pet.pet.data.repository;

import org.kodigo.pet.pet.data.models.Appointment;
import org.kodigo.pet.pet.data.models.Provide;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
    @Query("FROM Appointment WHERE provide_id=?1")
    List<Appointment> findByUserId(int userId);

}
