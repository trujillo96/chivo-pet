package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Client;
import org.kodigo.pet.pet.data.payloads.request.ClientRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public interface ClientService {
    MessageResponse createClient(ClientRequest clientRequest);
    Optional<Client> updateClient(Integer clientId, ClientRequest clientRequest);
    void deleteClient(Integer clientId);
    Client getASingleClient(Integer clientId);
    Client getClientByUserId(Integer userId);
    List<Client> getAllClients();
}
