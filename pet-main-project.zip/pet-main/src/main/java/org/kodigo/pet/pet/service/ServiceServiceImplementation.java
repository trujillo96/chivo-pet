package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Services;
import org.kodigo.pet.pet.data.payloads.request.ServiceRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.data.repository.ServiceRepository;
import org.kodigo.pet.pet.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServiceServiceImplementation implements ServiceService {
    @Autowired
    ServiceRepository serviceRepository;

    @Override
    public MessageResponse createService(ServiceRequest serviceRequest) {
        Services newService = new Services();
        newService.setService_name(serviceRequest.getService_name());
        newService.setPrice(serviceRequest.getPrice());
        newService.setQuantity(serviceRequest.getQuantity());

        serviceRepository.save(newService);

        return new MessageResponse("New Service created successfully");
    }

    @Override
    public Optional<Services> updateService(Integer service_id, ServiceRequest serviceRequest) throws ResourceNotFoundException {
        Optional<Services> service = serviceRepository.findById(service_id);

        if(service.isEmpty())
        {
            throw new ResourceNotFoundException("Service", "id", service_id);
        }
        else
        service.get().setService_name(serviceRequest.getService_name());
        service.get().setPrice(serviceRequest.getPrice());
        service.get().setQuantity(serviceRequest.getQuantity());

        serviceRepository.save(service.get());

        return service;
    }

    @Override
    public void deleteService(Integer service_id) throws ResourceNotFoundException {
        if(serviceRepository.getById(service_id).getService_id().equals(service_id))
        {
            serviceRepository.deleteById(service_id);
        }
        else throw new ResourceNotFoundException("Services", "id", service_id);
    }

    @Override
    public Services getASingleService(Integer service_id) {
        return serviceRepository.findById(service_id).orElseThrow(() -> new ResourceNotFoundException("Service", "id", service_id));
    }

    @Override
    public List<Services> getAllService() {
        return serviceRepository.findAll();
    }
}
