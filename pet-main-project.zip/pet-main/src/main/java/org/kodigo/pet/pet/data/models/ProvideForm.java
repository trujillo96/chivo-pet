package org.kodigo.pet.pet.data.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

public class ProvideForm {
    @Getter @Setter @JsonProperty
    private String pet;
    @Getter @Setter @JsonProperty
    private String service;
    @Getter @Setter @JsonProperty
    private String veterinary;
    @Getter @Setter @JsonProperty
    private String date;
    @Getter @Setter @JsonProperty
    private String hour;

    public ProvideForm() {
    }

    @Override
    public String toString() {
        return "ProvideForm{" +
                "pet='" + pet + '\'' +
                ", service='" + service + '\'' +
                ", veterinary='" + veterinary + '\'' +
                ", date='" + date + '\'' +
                ", hour='" + hour + '\'' +
                '}';
    }
}
