package org.kodigo.pet.pet.web;


import org.kodigo.pet.pet.data.models.Veterinary;
import org.kodigo.pet.pet.data.payloads.request.VeterinaryRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.service.VeterinaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/veterinary")
@RestController
public class VeterinaryController {
    @Autowired
    VeterinaryService veterinaryService;
    @GetMapping("/all")
    public ResponseEntity<List<Veterinary>> getAllVeterinary(){
        List<Veterinary> veterinary = veterinaryService.getAllVeterinary();
        return new ResponseEntity<>(veterinary, HttpStatus.OK);
    }
    @GetMapping("/find/{id}")
    public ResponseEntity<Veterinary> getVeterinaryById(@PathVariable("id") Integer id){
        Veterinary veterinary = veterinaryService.getASingleVeterinary(id);
        return new ResponseEntity<>(veterinary, HttpStatus.OK);
    }
    @PostMapping("/add")
    public ResponseEntity<MessageResponse> addVeterinary(@RequestBody VeterinaryRequest veterinary){
        MessageResponse newVeterinary = veterinaryService.createVeterinary(veterinary);
        return new ResponseEntity<>(newVeterinary, HttpStatus.CREATED);
    }
    @PutMapping("/update/{id}")
    public Optional<Veterinary> updateVeterinary(@PathVariable("id") Integer id,@RequestBody VeterinaryRequest veterinary){
        return veterinaryService.updateVeterinary(id, veterinary);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteVeterinary(@PathVariable("id") Integer id){
        veterinaryService.deleteVeterinary(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
