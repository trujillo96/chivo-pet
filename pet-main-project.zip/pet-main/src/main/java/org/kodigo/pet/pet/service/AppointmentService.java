package org.kodigo.pet.pet.service;


import org.kodigo.pet.pet.data.models.Appointment;
import org.kodigo.pet.pet.data.models.Provide;
import org.kodigo.pet.pet.data.payloads.request.AppointmentRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public interface AppointmentService {
    MessageResponse createAppointment(AppointmentRequest appointmentRequest);
    Optional<Appointment> updateAppointment(Integer appointmentId, AppointmentRequest appointmentRequest);
    void deleteAppointment(Integer appointmentId);
    Appointment getASingleAppointment(Integer appointmentId);
    List<Appointment> getAllAppointments();
    List<Appointment> getAppointmentsByProvideList(List<Provide> provides);
}
