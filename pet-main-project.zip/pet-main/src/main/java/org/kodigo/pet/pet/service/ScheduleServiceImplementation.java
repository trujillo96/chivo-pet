package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Pet;
import org.kodigo.pet.pet.data.models.Schedule;
import org.kodigo.pet.pet.data.payloads.request.ScheduleRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.data.repository.ScheduleRepository;
import org.kodigo.pet.pet.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScheduleServiceImplementation implements ScheduleService {
    @Autowired
    ScheduleRepository scheduleRepository;

    @Override
    public MessageResponse createSchedule(ScheduleRequest scheduleRequest) {
        Schedule newSchedule = new Schedule();
        newSchedule.setDay(scheduleRequest.getDay());
        newSchedule.setStart_hour(scheduleRequest.getStart_hour());
        newSchedule.setEnd_hour(scheduleRequest.getEnd_hour());
        newSchedule.setVeterinary_id(scheduleRequest.getVeterinary_id());

        scheduleRepository.save(newSchedule);

        return new MessageResponse("New Schedule created successfully");
    }

    @Override
    public Optional<Schedule> updateSchedule(Integer schedule_id, ScheduleRequest scheduleRequest) throws ResourceNotFoundException {
        Optional<Schedule> schedule = scheduleRepository.findById(schedule_id);

        if(schedule.isEmpty())
        {
            throw new ResourceNotFoundException("Schedule", "id", schedule_id);
        }
        else
            schedule.get().setDay(scheduleRequest.getDay());
        schedule.get().setStart_hour(scheduleRequest.getStart_hour());
        schedule.get().setEnd_hour(scheduleRequest.getEnd_hour());

        scheduleRepository.save(schedule.get());

        return schedule;
    }

    @Override
    public void deleteSchedule(Integer schedule_id) throws ResourceNotFoundException {
        if(scheduleRepository.getById(schedule_id).getSchedule_id().equals(schedule_id))
        {
            scheduleRepository.deleteById(schedule_id);
        }
        else throw new ResourceNotFoundException("Schedule", "id", schedule_id);
    }

    @Override
    public Schedule getASingleSchedule(Integer schedule_id) throws ResourceNotFoundException {
        return scheduleRepository.findById(schedule_id).orElseThrow(() -> new ResourceNotFoundException("Schedule", "id", schedule_id));
    }

    @Override
    public List<Schedule> getAllSchedules() {
        return scheduleRepository.findAll();
    }
}
