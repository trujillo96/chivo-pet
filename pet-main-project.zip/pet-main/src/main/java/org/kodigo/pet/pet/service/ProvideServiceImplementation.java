package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Pet;
import org.kodigo.pet.pet.data.models.Provide;
import org.kodigo.pet.pet.data.repository.ProvideRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class ProvideServiceImplementation implements ProvideService {
    @Autowired
    ProvideRepository provideRepository;
    @Override
    public List<Provide> getAllProvide() {
        return provideRepository.findAll();
    }

    @Override
    public List<Provide> getProvidesByPetList(List<Pet> pets){
        List<Provide> client = new ArrayList<Provide>();
        for(Pet pet : pets){
            client.addAll(provideRepository.findByPetId(pet.getPet_id()));
        }
        return client;
    }
}
