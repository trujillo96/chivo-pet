package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Client;
import org.kodigo.pet.pet.data.models.User;
import org.kodigo.pet.pet.data.repository.ClientRepository;
import org.kodigo.pet.pet.data.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {
    @Autowired
    private UserRepository repo;
    @Autowired
    private ClientRepository repoC;

    private User user;
    private Client client;

    public User loginUser(String email, String password){
        user = repo.findByEmailAndPassword(email, password);
        return user;
    }
    public Client loginClient(int id){
        client = repoC.findByUserId(id);
        return client;
    }
}