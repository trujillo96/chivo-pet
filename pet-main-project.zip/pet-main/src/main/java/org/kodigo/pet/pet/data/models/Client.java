package org.kodigo.pet.pet.data.models;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name="client")
public class Client {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter @Setter
    @Column(name = "client_id")
    private Integer clientId;
    @Getter @Setter
    private String name;
    @Getter @Setter
    private String lastName;
    @Getter @Setter
    private int phone;
    @Getter @Setter
    private String dui;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    @Getter @Setter
    private User user;



    public Client() {
    }

    public Client(Integer clientId, String name, String lastName, int phone, String dui) {
        this.clientId = clientId;
        this.name = name;
        this.lastName = lastName;
        this.phone = phone;
        this.dui = dui;
        this.user = new User();
    }
    @Override
    public String toString() {
        return "Client{" +
                "clientId=" + clientId +
                ", name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phone='" + phone + '\'' +
                ", dui='" + dui + '\'' +
                ", user=" + user +

                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Client client = (Client) o;
        return Objects.equals(clientId, client.clientId) && Objects.equals(name, client.name) && Objects.equals(lastName, client.lastName) && Objects.equals(phone, client.phone) && Objects.equals(dui, client.dui) && Objects.equals(user, client.user);
    }

    @Override
    public int hashCode() {
        return Objects.hash(clientId,name,lastName,phone,dui,user);
    }

}
