package org.kodigo.pet.pet.data.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name="status")
public class Status {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter @Setter
    @Column(name = "status_id")
    private Integer statusId;
    @Getter @Setter
    private String statusName;
    @Getter @Setter
    private Integer rescheduleId;

    public Status() {
    }

    public Status(Integer statusId, String statusName, Integer rescheduleId) {
        this.statusId = statusId;
        this.statusName = statusName;
        this.rescheduleId = rescheduleId;
    }

    @Override
    public String toString() {
        return "Status{" +
                "statusId=" + statusId +
                ", statusName='" + statusName + '\'' +
                ", rescheduleId='" + rescheduleId + '\'' +

                '}';
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Status status = (Status) o;
        return Objects.equals(statusId, status.statusId) && Objects.equals(statusName, status.statusName) && Objects.equals(rescheduleId, status.rescheduleId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(statusId,statusName,rescheduleId);
    }
}
