package org.kodigo.pet.pet.data.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Time;
import java.util.Date;
import java.util.Objects;
import java.util.TimeZone;
import java.util.Timer;

@Entity
@Table(name = "schedule")
public class Schedule {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter @Setter
    @Column(name = "schedule_id")
    private Integer schedule_id;
    @Getter @Setter
    private Date day;
    @Getter @Setter
    private Time start_hour;
    @Getter @Setter
    private Time end_hour;
    @Getter @Setter
    private Integer veterinary_id;

    public Schedule() {
    }

    public Schedule(Integer schedule_id, Date day, Time start_hour, Time end_hour, Integer veterinary_id) {
        this.schedule_id = schedule_id;
        this.day = day;
        this.start_hour = start_hour;
        this.end_hour = end_hour;
        this.veterinary_id = veterinary_id;
    }

    @Override
    public String toString() {
        return "Schedule{" +
                "schedule_id=" + schedule_id +
                ", day=" + day +
                ", start_hour=" + start_hour +
                ", end_hour=" + end_hour +
                ", veterinary_id=" + veterinary_id +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Schedule schedule = (Schedule) o;
        return Objects.equals(schedule_id, schedule.schedule_id) && Objects.equals(day, schedule.day) && Objects.equals(start_hour, schedule.start_hour) && Objects.equals(end_hour, schedule.end_hour) && Objects.equals(veterinary_id, schedule.veterinary_id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(schedule_id, day, start_hour, end_hour, veterinary_id);
    }
}
