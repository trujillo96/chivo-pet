package org.kodigo.pet.pet.data.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name="provide")
public class Provide implements Serializable {
    @Id
    @Getter @Setter
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "provide_id")
    private Integer provideId;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "veterinary_id", referencedColumnName = "veterinary_id")
    @Getter @Setter
    private Veterinary veterinary;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "pet_id", referencedColumnName = "pet_id")
    @Getter @Setter
    private Pet pet;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "service_id", referencedColumnName = "service_id")
    @Getter @Setter
    private Services service;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "appointment_id", referencedColumnName = "appointment_id")
    @Getter @Setter
    private Appointment appointment;


    public Provide(Integer provideId, Veterinary veterinary, Pet pet, Services service, Appointment appointment) {
        this.provideId = provideId;
        this.veterinary = veterinary;
        this.pet = pet;
        this.service = service;
        this.appointment = appointment;
    }

    public Provide() {
    }

    @Override
    public String toString() {
        return "Provide{" +
                "provideId=" + provideId +
                ", veterinary='" + veterinary + '\'' +
                ", pet='" + pet + '\'' +
                ", service='" + service + '\'' +
                ", appointment='" + appointment + '\'' +

                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Provide provide = (Provide) o;
        return Objects.equals(provideId, provide.provideId) && Objects.equals(veterinary, provide.veterinary) && Objects.equals(pet, provide.pet) && Objects.equals(service, provide.service) && Objects.equals(appointment, provide.appointment);
    }

    @Override
    public int hashCode() {
        return Objects.hash(provideId,pet,service,appointment);
    }

}
