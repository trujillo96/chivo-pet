package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Schedule;
import org.kodigo.pet.pet.data.payloads.request.ScheduleRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public interface ScheduleService {
    MessageResponse createSchedule(ScheduleRequest scheduleRequest);
    Optional<Schedule> updateSchedule(Integer schedule_id, ScheduleRequest scheduleRequest);
    void deleteSchedule(Integer schedule_id);
    Schedule getASingleSchedule(Integer schedule_id);
    List<Schedule> getAllSchedules();
}
