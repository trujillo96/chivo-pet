package org.kodigo.pet.pet.data.repository;


import org.kodigo.pet.pet.data.models.Services;
import org.kodigo.pet.pet.data.models.Veterinary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface VeterinaryRepository extends JpaRepository<Veterinary, Integer> {
    ArrayList<Veterinary> findAll();

    @Query("FROM Veterinary WHERE veterinary_id=?1")
    Veterinary findByUserId(int vetId);
}
