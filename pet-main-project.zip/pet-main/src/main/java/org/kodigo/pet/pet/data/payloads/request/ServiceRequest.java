package org.kodigo.pet.pet.data.payloads.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class ServiceRequest {
    @NotBlank
    @NotNull
    @Getter @Setter
    private String service_name;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Integer price;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Integer quantity;

}
