package org.kodigo.pet.pet.web;

import org.kodigo.pet.pet.data.models.Pet;
import org.kodigo.pet.pet.data.models.Schedule;
import org.kodigo.pet.pet.data.payloads.request.PetRequest;
import org.kodigo.pet.pet.data.payloads.request.ScheduleRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.service.ScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/schedule")
@RestController
public class ScheduleController {

    @Autowired
    ScheduleService scheduleService;

    @GetMapping("/all")
    public ResponseEntity<List<Schedule>> getAllSchedules(){
        List<Schedule> schedules = scheduleService.getAllSchedules();
        return new ResponseEntity<>(schedules, HttpStatus.OK);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<Schedule> getScheduleById(@PathVariable("id") Integer id){
        Schedule schedule = scheduleService.getASingleSchedule(id);
        return new ResponseEntity<>(schedule, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<MessageResponse> addSchedule(@RequestBody ScheduleRequest schedule){
        MessageResponse newSchedule = scheduleService.createSchedule(schedule);
        return new ResponseEntity<>(newSchedule, HttpStatus.CREATED);
    }

    @PutMapping("/update/{id}")
    public Optional<Schedule> updateSchedule(@PathVariable Integer id, @RequestBody ScheduleRequest schedule){
        return scheduleService.updateSchedule(id, schedule);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteSchedule(@PathVariable("id") Integer id){
        scheduleService.deleteSchedule(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
