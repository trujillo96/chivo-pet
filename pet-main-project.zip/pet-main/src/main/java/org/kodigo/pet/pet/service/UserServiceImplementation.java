package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.User;
import org.kodigo.pet.pet.data.payloads.request.UserRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.data.repository.UserRepository;
import org.kodigo.pet.pet.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImplementation implements UserService {
    @Autowired
    UserRepository userRepository;

    @Override
    public MessageResponse createUser(UserRequest userRequest) {
        User newUser = new User();
        newUser.setEmail(userRequest.getEmail());
        newUser.setPassword(userRequest.getPassword());
        newUser.setRoleId(userRequest.getRoleId());

        userRepository.save(newUser);

        return new MessageResponse("New User created successfully");
    }

    @Override
    public Optional<User> updateUser(Integer userId, UserRequest userRequest) throws ResourceNotFoundException {
        Optional<User> user = userRepository.findById(userId);

        if(user.isEmpty())
        {
            throw new ResourceNotFoundException("User", "id", userId);
        }
        else
            user.get().setEmail(userRequest.getEmail());
        user.get().setPassword(userRequest.getPassword());

        userRepository.save(user.get());

        return user;
    }

    @Override
    public void deleteUser(Integer userId) throws ResourceNotFoundException {
        if(userRepository.getById(userId).getUserId().equals(userId))
        {
            userRepository.deleteById(userId);
        }
        else throw new ResourceNotFoundException("User", "id", userId);
    }

    @Override
    public User getASingleUser(Integer userId) throws ResourceNotFoundException {
        return userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
    }

    @Override
    public User getUserByEmail(String email, String password){
        return userRepository.findByEmailAndPassword(email, password);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
}
