package org.kodigo.pet.pet.data.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Time;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name="appointment")
public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter
    @Setter
    @Column(name = "appointment_id")
    private Integer appointmentId;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "status_id", referencedColumnName = "status_id")
    @Getter @Setter
    private Status status;

    @Getter @Setter
    private Integer scheduleId;
    @Getter @Setter
    private Time hour;

    public Appointment(){}

    public Appointment(Integer appointmentId, Integer scheduleId, Time hour) {
        this.appointmentId = appointmentId;
        this.status = new Status();
        this.scheduleId = scheduleId;
        this.hour = hour;
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentId=" + appointmentId +
                ", status=" + status +
                ", scheduleId=" + scheduleId +
                ", hour=" + hour +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Appointment appointment = (Appointment) o;
        return Objects.equals(appointmentId, appointment.appointmentId) && Objects.equals(status, appointment.status) && Objects.equals(scheduleId, appointment.scheduleId) && Objects.equals(hour, appointment.hour) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentId, status, scheduleId, hour);
    }
}
