package org.kodigo.pet.pet.web;

import org.kodigo.pet.pet.data.models.*;
import org.kodigo.pet.pet.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.management.relation.Role;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Controller
public class AppController {
    @Autowired
    private UserServiceImplementation userService;
    @Autowired
    private ClientServiceImplementation clientService;
    @Autowired
    private PetServiceImplementation petService;
    @Autowired
    private VeterinaryServiceImplementation veterinaryService;
    @Autowired
    private ServiceServiceImplementation serviceService;
    @Autowired
    private AppointmentServiceImplementation appointmentService;
    @Autowired
    private ProvideServiceImplementation provideService;
    @Autowired
    private ScheduleServiceImplementation scheduleService;

    private User authUser;
    private Role authRole;
    private Client authClient;
    private List<Pet> pets;
    private List<Services> services;
    private List<Veterinary> veterinaries;
    private List<Provide> provides;
    private List<Appointment> appointments;

    public AppController() {}

    @GetMapping(value={"/login", "/"})
    public ModelAndView login(){
        ModelAndView mv = new ModelAndView();
        mv.setViewName("login");
        return mv;
    }

    public void updateInfo(){
        authClient = clientService.getClientByUserId(authUser.getUserId());
        pets = petService.getAClientPet(authClient.getClientId());
        provides = provideService.getProvidesByPetList(pets);
        appointments = appointmentService.getAppointmentsByProvideList(provides);

    }

    @PostMapping(value="/login")
    public ModelAndView login(@ModelAttribute("user") User user){
        authUser = userService.getUserByEmail(user.getEmail(), user.getPassword());

        if(Objects.nonNull(authUser)) {
            veterinaries = veterinaryService.getAllVeterinary();
            services = serviceService.getAllService();
            updateInfo();
            ModelAndView mv = new ModelAndView("redirect:/home");
            return mv;
        }
        ModelAndView mv = new ModelAndView("redirect:/login");
        return mv;
    }

    @GetMapping(value="/home")
    public ModelAndView home(){
        if(!Objects.nonNull(authUser)){
            return login();
        }
        updateInfo();
        ModelAndView mv = new ModelAndView();
        mv.addObject("name", authClient.getName());
        if(authUser.getRoleId() == 3){
            String auditTag = "<a href=\"audit.html\" class=\"nav-link px-2 link-secondary\">Audit</a>";
            mv.addObject("audit", auditTag);
        }
        mv.setViewName("home");
        return mv;
    }

    @GetMapping(value="/petsView")
    public ModelAndView pets(){
        if(!Objects.nonNull(authUser)){
            return login();
        }
        updateInfo();
        String displayPets = "";
        for(int i = 0; i < pets.size(); i++){
            displayPets = displayPets
                    + "<tr>"
                    + "<th scope=\"row\">"+ (i+1) + "</th>"
                    + "<td>" + pets.get(i).getName() + "</td>"
                    + "<td>" + pets.get(i).getBreed() + "</td>"
                    + "<td>" + pets.get(i).getBirth() + "</td>"
                    + "<td><a href=\"#\" class=\"nav-link px-2 link-warning\">Editar</a></td>"
                    + "</tr>";

        }
        ModelAndView mv = new ModelAndView();
        mv.addObject("pets", displayPets);
        mv.setViewName("petsView");

        return mv;

    }

    @GetMapping(value="/agregarCitaView")
    public ModelAndView agregarCita(){
        if(!Objects.nonNull(authUser)){
            return login();
        }
        updateInfo();
        ModelAndView mv = new ModelAndView("agregarCitaView");
        mv.addObject("provideForm", new ProvideForm());
        List<String> displayPets = new ArrayList<String>();
        for(Pet p : pets){
            displayPets.add(p.getName());
        }
        mv.addObject("p", displayPets);

        List<String> displayServices = new ArrayList<String>();
        for(Services s : services){
            displayServices.add(s.getService_name());
        }
        mv.addObject("s", displayServices);

        List<String> displayVeterinaries = new ArrayList<String>();
        for(Veterinary v : veterinaries){
            displayVeterinaries.add(v.getVeterinary_name());
        }
        mv.addObject("v", displayVeterinaries);
        return mv;
    }

    @PostMapping(value="/agregarCitaView")
    public ModelAndView postAppointment(ProvideForm pr){
        System.out.println(pr.toString());
        ModelAndView mv = new ModelAndView("redirect:/appointmentView");
        return mv;
    }

    @GetMapping(value="/appointmentView")
    public ModelAndView appointment(){

        if(!Objects.nonNull(authUser)){
            return login();
        }
        updateInfo();

//        System.out.println("Appointments: " + appointments.size());
//        String str2 = petService.getASinglePet(appointments.get(0).getPet_id()).getName();
//        String str3 = aService.getASingleService(appointments.get(0).getService_id()).getService_name();
//        String str4 = appointments.get(0).getDate().toString();
//        String str5 = appointments.get(0).getHour().toString();
//        String str6 = vetService.getAVeterinary(appointments.get(0).getVeterinary_id()).getVeterinary_name();
//
//        System.out.println("Petname: " + str2);
//        System.out.println("Service: " + str3);
//        System.out.println("Date: " + str4);
//        System.out.println("Time: " + str5);
//        System.out.println("Vet: " + str6);

        String displayAppointment = "";
        int i = 1;
        for(Provide provide : provides){
            String str1 = (i++) + "";
            String str2 = petService.getASinglePet(provide.getPet().getPet_id()).getName();
            String str3 = serviceService.getASingleService(provide.getService().getService_id()).getService_name();
            Appointment app = appointmentService.getASingleAppointment(provide.getAppointment().getAppointmentId());
            String str4 = scheduleService.getASingleSchedule(app.getScheduleId()).getDay().toString();
            str4 = str4.substring(0, 10);
            DateFormat dateFormat = new SimpleDateFormat("hh:mm aa");
            String str5 = dateFormat.format(scheduleService.getASingleSchedule(app.getScheduleId()).getStart_hour());
            String str6 = veterinaryService.getASingleVeterinary(provide.getVeterinary().getVeterinary_id()).getVeterinary_name();


            displayAppointment = displayAppointment
                    + "<tr>"
                    + "<th scope=\"row\">"+ str1 + "</th>"
                    + "<td>" + str2 + "</td>"
                    + "<td>" + str3 + "</td>"
                    + "<td>" + str4 + "</td>"
                    + "<td>" + str5 + "</td>"
                    + "<td>" + str6 + "</td>"
                    + "<td>Activo</td>"
                    + "<td><a href=\"#\" class=\"nav-link px-2 link-warning\">Editar</a></td>"
                    + "</tr>";
        }

        ModelAndView mv = new ModelAndView();
        mv.addObject("appts", displayAppointment);
        mv.setViewName("appointmentView");

        return mv;

    }

    @GetMapping(value={"/logout"})
    public ModelAndView logout(){
        authClient = null;
        ModelAndView mv = new ModelAndView("redirect:/login");
        return mv;
    }


}