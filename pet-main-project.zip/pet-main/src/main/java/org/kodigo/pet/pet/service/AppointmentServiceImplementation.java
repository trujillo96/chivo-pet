package org.kodigo.pet.pet.service;

import org.kodigo.pet.pet.data.models.Appointment;
import org.kodigo.pet.pet.data.models.Provide;
import org.kodigo.pet.pet.data.payloads.request.AppointmentRequest;
import org.kodigo.pet.pet.data.payloads.response.MessageResponse;
import org.kodigo.pet.pet.data.repository.AppointmentRepository;
import org.kodigo.pet.pet.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AppointmentServiceImplementation implements AppointmentService{
    @Autowired
    private AppointmentRepository appointmentRepository;

    private ArrayList<Appointment> appointments;

    @Override
    public MessageResponse createAppointment(AppointmentRequest appointmentRequest) {
        Appointment newAppointment = new Appointment();
        newAppointment.setStatus(appointmentRequest.getStatus());
        newAppointment.setScheduleId(appointmentRequest.getScheduleId());
        newAppointment.setHour(appointmentRequest.getHour());
        newAppointment.getStatus().setStatusName("Active");


        appointmentRepository.save(newAppointment);
        return new MessageResponse("New Appointment created successfully");
    }

    @Override
    public Optional<Appointment> updateAppointment(Integer appointmentId, AppointmentRequest appointmentRequest) throws ResourceNotFoundException {
        Optional<Appointment> appointment = appointmentRepository.findById(appointmentId);
        if(appointment.isEmpty()){
            throw new ResourceNotFoundException("Appointment","id",appointmentId);
        } else
            appointment.get().setStatus(appointmentRequest.getStatus());
            appointment.get().setScheduleId(appointmentRequest.getScheduleId());
            appointment.get().setHour(appointmentRequest.getHour());
            appointmentRepository.save(appointment.get());

        return appointment;
    }

    @Override
    public void deleteAppointment(Integer appointmentId) throws ResourceNotFoundException {
        if(appointmentRepository.getById(appointmentId).getAppointmentId().equals(appointmentId)){
            appointmentRepository.deleteById(appointmentId);
        }
        else throw new ResourceNotFoundException("Appointment","id", appointmentId);

    }

    @Override
    public Appointment getASingleAppointment(Integer appointmentId) throws ResourceNotFoundException {
        return appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment", "id", appointmentId));
    }

    @Override
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }


    public void insertAppointment(Appointment toQuery){
        appointmentRepository.save(toQuery);
    }

    @Override
    public List<Appointment> getAppointmentsByProvideList(List<Provide> provides){
        List<Appointment> client = new ArrayList<Appointment>();
        for(Provide provide : provides) {
            client.add(getASingleAppointment(provide.getAppointment().getAppointmentId()));
        }
        return client;
    }
}
