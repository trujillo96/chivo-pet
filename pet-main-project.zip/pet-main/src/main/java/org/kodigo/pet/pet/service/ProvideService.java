package org.kodigo.pet.pet.service;



import org.kodigo.pet.pet.data.models.Pet;
import org.kodigo.pet.pet.data.models.Provide;
import org.kodigo.pet.pet.data.models.Schedule;

import java.util.List;

public interface ProvideService {
    List<Provide> getAllProvide();
    List<Provide> getProvidesByPetList(List<Pet> pets);
}
