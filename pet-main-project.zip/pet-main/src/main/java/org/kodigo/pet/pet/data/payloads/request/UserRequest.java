package org.kodigo.pet.pet.data.payloads.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class UserRequest {
    @NotBlank
    @NotNull
    @Email
    @Getter @Setter
    private String email;
    @NotBlank
    @NotNull
    @Getter @Setter
    private String password;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Integer roleId;
}
