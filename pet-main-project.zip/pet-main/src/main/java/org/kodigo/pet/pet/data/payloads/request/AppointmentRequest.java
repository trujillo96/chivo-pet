package org.kodigo.pet.pet.data.payloads.request;

import lombok.Getter;
import lombok.Setter;
import org.kodigo.pet.pet.data.models.Status;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.sql.Time;

public class AppointmentRequest {

    @NotBlank
    @NotNull
    @Getter @Setter
    private Status status;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Integer scheduleId;
    @NotBlank
    @NotNull
    @Getter @Setter
    private Time hour;
}
